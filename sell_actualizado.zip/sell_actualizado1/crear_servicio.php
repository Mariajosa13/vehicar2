<?php
    
  //la informacion solo se envia si le das al boton. if (condicion) (isset (para verificar) ($_POST (metodo de envio mas seguro) ['btn_registrar'] (nombre del boton en el form)))
  if(isset($_POST['btn_servicio'])){

    // llamar a la conexion de otro archivo (poner el nombre del otro archivo php)
    include ("conexion.php");


    //llamado de las variables ej: $nom_1 (nombre inventado) = $_POST (metodo de envio) ['nombre1'] (nombre en el formulario); 
    $cod_s = $_POST['cs'];
    $fe_ini = $_POST['fi'];
    $fe_fin = $_POST['ff'];
    $tip_s = $_POST['ts'];
    $report_s = $_POST['rs'];
    $des_s = $_POST['ds'];
    $serv_c = $_POST['sc'];
    $fk_usu = $_POST['id_usu'];

  
    //registrar los datos en la tabla $registrar (variable)= mysqli_query (para insertar codigo de mysql) ($conexion (variable), "insert into usuario (nombre de la tabla) (nombres de los campos en phpmyadmin) values (nombre de las variables)")
    $registrar = mysqli_query($conexion,"INSERT INTO `reporte_servicios` (`cod_serv`, `fecha_ini`, `fecha_fin`, `tipo_servicio`, `reporte_servicios`, `descrip_serv`, `servicio_concre`, `fk_usu_repor`) VALUES ('$cod_s', '$fe_ini', '$fe_fin', '$tip_s', '$report_s', '$des_s', '$serv_c', '$fk_usu');");

    echo "<script> alert('Registro exitoso'); </script>";

    echo "<script> window.location='index.php'; </script>";
  } 
  
?>