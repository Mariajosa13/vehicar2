<!-- partial -->
<div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-6 grid-margin stretch-card"  style="height: 20rem">
              <div class="card">
                <div class="card-body">
                <div class="dropdown-header text-center">
                <h4 class="card-title">Maria Soto Torres</h4>
                <img class="img-md rounded-circle" src="img/icono.png" alt="Profile image" style="height: 80px; weight:80px;"> <hr>
                <h6 style="text-align: center">Profesional en Veterinaria</h6>
                <h6 style="text-align: center">Medellín</h6>
                <h6 style="text-align: center">C.C 1.787.156.244</h6>
                <h6 style="text-align: center">mari@gmail.com</h6>
              </div> 
                  <canvas id="lineChart"></canvas>
                </div>
              </div>
            </div>
            <div class="col-lg-6 grid-margin stretch-card"  style="height: 20rem">
              <div class="card">
                <div class="card-body">
                <div class="dropdown-header text-center">
                <h4 class="card-title">Eliana Rámirez Calle</h4>
                <img class="img-md rounded-circle" src="img/icono.png" alt="Profile image" style="height: 80px; weight:80px;"> <hr>
                <h6 style="text-align: center">Profesional en Veterinaria</h6>
                <h6 style="text-align: center">Medellín</h6>
                <h6 style="text-align: center">C.C 1.289.226.954</h6>
                <h6 style="text-align: center">ramirezEli@gmail.com</h6>
              </div> 
                  <canvas id="barChart"></canvas>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
          <div class="col-lg-6 grid-margin stretch-card"  style="height: 20rem">
              <div class="card">
                <div class="card-body">
                <div class="dropdown-header text-center">
                <h4 class="card-title">Danny Ibaguez Díaz</h4>
                <img class="img-md rounded-circle" src="img/icono.png" alt="Profile image" style="height: 80px; weight:80px;"> <hr>
                <h6 style="text-align: center">Profesional en Veterinaria</h6>
                <h6 style="text-align: center">Medellín</h6>
                <h6 style="text-align: center">C.C 1.017.056.234</h6>
                <h6 style="text-align: center">ibaguez2@gmail.com</h6>
              </div> 
                  <canvas id="areaChart"></canvas>
                </div>
              </div>
            </div>
            <div class="col-lg-6 grid-margin stretch-card"  style="height: 20rem">
              <div class="card">
                <div class="card-body">
                <div class="dropdown-header text-center">
                <h4 class="card-title">Sandra Ospina Puerta</h4>
                <img class="img-md rounded-circle" src="img/icono.png" alt="Profile image" style="height: 80px; weight:80px;"> <hr>
                <h6 style="text-align: center">Profesional en Veterinaria</h6>
                <h6 style="text-align: center">Medellín</h6>
                <h6 style="text-align: center">C.C 1.266.357.046</h6>
                <h6 style="text-align: center">sandraO2@gmail.com</h6>
              </div> 
                </div>
              </div>
            </div>
          </div>
          <div class="row">
          <div class="col-lg-6 grid-margin stretch-card"  style="height: 20rem">
              <div class="card">
                <div class="card-body">
                <div class="dropdown-header text-center">
                <h4 class="card-title">Isabel Giraldo Cardenas</h4>
                <img class="img-md rounded-circle" src="img/icono.png" alt="Profile image" style="height: 80px; weight:80px;"> <hr>
                <h6 style="text-align: center">Profesional en Veterinaria</h6>
                <h6 style="text-align: center">Medellín</h6>
                <h6 style="text-align: center">C.C 1.557.908.254</h6>
                <h6 style="text-align: center">67isabel@gmail.com</h6>
              </div> 
                  <canvas id="pieChart"></canvas>
                </div>
              </div>
            </div>
            <div class="col-lg-6 grid-margin stretch-card"  style="height: 20rem">
              <div class="card">
                <div class="card-body">
                <div class="dropdown-header text-center">
                <h4 class="card-title">Daniel Zuluaga Pérez</h4>
                <img class="img-md rounded-circle" src="img/icono.png" alt="Profile image" style="height: 80px; weight:80px;"> <hr>
                <h6 style="text-align: center">Profesional en Veterinaria</h6>
                <h6 style="text-align: center">Medellín</h6>
                <h6 style="text-align: center">C.C 1.347.666.104</h6>
                <h6 style="text-align: center">daniel@gmail.com</h6>
              </div> 
                  <canvas id="scatterChart"></canvas>
                </div>
              </div>
            </div>
          </div>
        </div>