<!-- Crear servicios -->

          <div class="row" style="margin-left:20%;">
            <div class="col-md-8 grid-margin stretch-card" style="margin-right:20%;">
              <div class="card" style="display: flex; flex-direction: column; justify-content: center; align-items: center;">
                <div class="card-body">
                  <div class="myform">

            <div class="titulo">
              <h4 style="text-align: center;">Crear Servicios</h4>
              <center> <p class="card-description">
                    ¡Hola, <?php echo $_SESSION['nombre'];?>! 
                    Aquí puedes Crear un servicio.
                  </p> </center>
            </div>  

          <form action="crear_servicio.php" method="post" name="crear_servicio">
  
            <div class="base col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12" style="column-count:2;">

              <div class="form-group">
                <input type="text" name="id_usu" class="form-control" id="id_usu" placeholder="Número identificación" required />
              </div>

              <div class="form-group">
                <input type="text" name="cs" class="form-control" id="cs" placeholder="Codigo servicio" required />
              </div>

              <div class="form-group">
                <span>Fecha de Inicio</span>
                <input type="date" name="fi" class="form-control campo_form" id="fi" placeholder="" required />
              </div>

              <div class="form-group">
                <span>Fecha de Fin</span>
                <input type="date" name="ff" class="form-control campo_form" id="ff" placeholder="" required />
              </div>

              <div class="form-group">
                <input type="text" name="ts" class="form-control" id="ts" placeholder="Tipo de servicio" required />
              </div>

              <div class="form-group">
                <input type="text" name="rs" id="rs" class="form-control" placeholder="Reporte de servicio" required />
              </div>

              <div class="form-group">
                <span style="color:white;">...</span>
                <input type="text" name="ds" id="ds" class="form-control" placeholder="Descripción del servicio" required />
              </div>


              <div class="form-group">
                <span style="color: white;">...</span>
                <input type="text" name="sc" class="form-control" id="sc" placeholder="Servicio concretado" required />
              </div>

            </div>

            <div class="col-md-12 text-center mb-3" style="justify-content: center;">
              <button type="submit" class="btn btn-block mybtn btn-success tx-tfm" name="btn_servicio" style="border-radius: 60px; background-color: #94D49F; width: 100px; margin-top: 8px; color: #010101;">Crear</button>
            </div>

          </form>




</div>
</div>
    