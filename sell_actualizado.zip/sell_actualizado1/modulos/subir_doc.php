<div class="row" style="margin-left:20%;">
            <div class="col-md-8 grid-margin stretch-card" style="margin-right:20%;">
              <div class="card" style="display: flex; flex-direction: column; justify-content: center; align-items: center;">
                <div class="card-body">
                  <div class="myform">

            <div class="titulo">
              <h4 style="text-align: center;">Subir archivo</h4>
              <center> <p class="card-description">
                    ¡Hola, <?php echo $_SESSION['nombre'];?>! 
                    Aquí puedes subir archivos.
                  </p> </center>
            </div>  

          <form action="subir_docu.php" method="post" name="registration">

           
            <div class="base col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12" style="column-count:2;">

            <div class="form-group">
                <input type="text" name="nu_id" class="form-control" id="nu_id" placeholder="Número de identificación" required />
              </div>

            <div class="form-group">
                <input type="text" name="ca" class="form-control" id="ca" placeholder="Código archivo" required />
              </div>

              <div class="form-group">
                <span>Fecha subida</span>
                <input type="date" name="fs" class="form-control campo_form" id="fs" placeholder="Fecha subida" required />
              </div>

              <div class="form-group">
                <input type="text" name="ta" class="form-control" id="ta" placeholder="Tipo de archivo" required />
              </div>

              <div class="form-group">
                <input type="text" name="na" id="na" class="form-control" placeholder="Nombre archivo" required />
              </div>

              <div class="form-group">
                <span style="color:white;">...</span>
                <input type="text" name="da" id="da" class="form-control" placeholder="Descripción archivo" required />
              </div>
            </div>

            <div class="form-group">
                <label for="historial"><strong>Subir:</strong></label>
                <input type="file" name="historial" id="historial">
            </div>

            <div class="col-md-12 text-center mb-3" style="justify-content: center;">
              <button type="submit" class="btn btn-block mybtn btn-success tx-tfm" name="btn_documento" style="border-radius: 60px; background-color: #94D49F; width: 100px; margin-top: 8px; color: #010101;">Subir</button>
            </div>

          </form>

</div>
</div>
    