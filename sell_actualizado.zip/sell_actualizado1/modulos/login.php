<?php
//Abrimos la sesion
session_start();
if(isset($_SESSION['nu_id'])){
 echo "<script> window.location='dashboard.php'; </script>";
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">

   <!-- CSS only -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

   <!-- JavaScript Bundle with Popper -->
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4"
      crossorigin="anonymous"></script>

  <!--Favicon-->
  <link rel="icon" type="image/jpg" href="img/favicon.png" />

  <!--CSS Propio-->
  <link rel="stylesheet" type="text/css" href="estilos2.css" />

  <title>Ingresar - Sell & Work</title>
</head>

<body>
  <center>
          <div class="myform">

                <div class="titulo">
                  <h1> Inicio de sesión </h1>
                </div>
 
                  <div class="logo">
                    <img src="img/logo.png" class="logo" alt="Logo">
                  </div>

                    <form action="index.php" method="post">
                    <?php
                      //Traemos la conexion

                      include "conexion.php";


                      //Verificamos la accion del boton

                      if(isset($_POST['btn_ingresar'])) {
                        //recolectamos las variables
                        $nu_id = $_POST['gmail'];
                        $contrasena = $_POST['password'];

                        //encriptamos la contraseña
                        $encrip = md5($contrasena);

                        //realizamos la consulta a la bd

                        $consultar = mysqli_query($conexion, "SELECT * FROM usuario WHERE email = '$nu_id' AND pass = '$encrip'");

                        //Verificamos si encontro el usuario

                        $resultado = mysqli_num_rows($consultar);
                        //validamos si encontro el usuario
                        if ($resultado == 1) {
                           //creamos las variables de la sesion
                           while($fila = mysqli_fetch_array($consultar)){
                            $_SESSION['nu_id'] = $fila['email'];
                            $_SESSION['nombre'] = $fila['nom_1'];
                            $_SESSION['apellido'] = $fila['ape_1'];
                            $_SESSION['rol'] = $fila['fk_rol_usu'];

                            //Redirigimos al dashboard
                            echo "<script> window.location='dashboard.php'; </script>";
                            
                           }
                          
                        } else{ 
                          
                          
                          //mostramos mensaje
                          
                          echo "Usuario y/o Clave no coinciden";
                        }

                      }

                    ?>
                <br>
                <!--
                    <div class="form-group">
                      <label for="Select1"></label>
                        <select class="campo_form" name="tipo_usu" id="Select1">
                          <option class="opcion">Tipo de usuario</option>
                          <option>Vendedor</option>
                          <option>Cliente</option>
                        </select>
                    </div> -->


                  <div class="form-group">
                    <input type="text" name="gmail" class="form-control" id="email" aria-describedby="emailHelp"
                      placeholder="Correo electrónico">
                  </div>
                  <br>
                  <div class="form-group">
                    <input type="password" name="password" id="password" class="form-control"
                      aria-describedby="emailHelp" placeholder="Contraseña">
                  </div>

                  <div class="col">
                    <button type="submit" class="btn btn-block mybtn btn-success tx-tfm" name="btn_ingresar">Ingresar</button>
                  </div> 
                  <br>

                </form>

                <div class="vinculo">
                  <p>¿No tienes una cuenta? <a href="registrar.php" id="signup">Regístrate</a>
                  </p>
                </div>

                <div class="vinculo">
                  <a href="recuperar_contra.php">¿Olvidaste tu contraseña?</a>
                </div>

          </div> 
  </center>
</body>

</html>