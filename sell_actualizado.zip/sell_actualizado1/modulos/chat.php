
    <!--CSS Propio-->
    <link rel="stylesheet" type="text/css" href="estilosreg.css" />

    <!--Favicon-->
</head>
<body>
<div class="wrapper">
    <section class="chat-area">
        <header>
            <a href="#" class="back-icon"><i class="fa-solid fa-arrow-left" style="color: #ffffff;"></i></a>
            <img src="img/icono.png" alt="icono">
            <div class="details">
                <span>Maria José</span>
                <p>Online</p>
            </div>
        </header>
        <div class="chat-box">
            <div class="chat outgoing">
                <div class="details">
                    <p>wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww</p>
                </div>
            </div>
            <div class="chat incoming">
                <img src="img/icono.png" alt="">
                <div class="details">
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                </div>
            </div>
            <div class="chat outgoing">
                <div class="details">
                    <p>wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww</p>
                </div>
            </div>
            <div class="chat incoming">
                <img src="img/icono.png" alt="">
                <div class="details">
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                </div>
            </div>
            <div class="chat outgoing">
                <div class="details">
                    <p>wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww</p>
                </div>
            </div>
            <div class="chat incoming">
                <img src="img/icono.png" alt="">
                <div class="details">
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                </div>
            </div>
            <div class="chat outgoing">
                <div class="details">
                    <p>wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww</p>
                </div>
            </div>
            <div class="chat incoming">
                <img src="img/icono.png" alt="">
                <div class="details">
                    <p>Lorem ipsum dolor sit amet consectetur.</p>
                </div>
            </div>
        </div>
        <form action="" class="typing-area" method="post">
            <input type="text" placeholder="Escribe un mensaje...">
            <button><i class="fa-brands fa-telegram" style="color: #ccc;"></i></button>
        </form>
    </section>
</div>
