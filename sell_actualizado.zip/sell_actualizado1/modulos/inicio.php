<div class="container-fluid">


        <img src="img/ilustraciongoogle.svg" alt="" style="width: 50%; height:35%; min-width: 20rem;" class="base col-xl-6 col-lg-6 col-md-12 col-sm-12 col-xs-12" >

          <div class="font" style="float:right; margin-top:10%; width:40%; height: 40%; min-width:20rem;">
          <h1 class="welcome-text">Bienvenido a <br>
           <span class="text-black fw-bold" style="font-color: #b4dbbb" class="base col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6">Sell&Work, <br>
             </span><?php echo $_SESSION['nombre'];?></h1>
          </div> 
</div>

       
        <ul class="navbar-nav">
          <li class="nav-item font-weight-semibold d-none d-lg-block ms-0">
            
          </li>
        </ul>