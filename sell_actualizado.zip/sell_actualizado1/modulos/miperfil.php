<div class="col-lg-12 grid-margin stretch-card"  style="height: 25rem">
              <div class="card">
                <div class="card-body">
                <div class="dropdown-header text-center">
                <h3><?php echo $_SESSION['nombre'];?></h3>
                <img class="img-md rounded-circle" src="img/icono.png" alt="Profile image" style="height: 80px; weight:80px;"> <hr>
                <h6 style="text-align: center">Medellín</h6>
                <h6 style="text-align: center"><?php echo $_SESSION['nu_id'];?></h6>
              </div> 
                  <canvas id="scatterChart"></canvas>
                </div>
              </div>
            </div>
          </div>
        </div>