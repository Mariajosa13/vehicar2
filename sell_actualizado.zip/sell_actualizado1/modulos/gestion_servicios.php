<?php
// Incluir la conexion
include './conexion.php';

// Verificar el boton buscar
if(isset($_SESSION['nu_id'])){

if (isset($_POST['btn_eliminar'])){

$doc = $_POST['doc_eliminar'];

$eliminar = mysqli_query($conexion,"DELETE FROM reporte_servicios WHERE `reporte_servicios`.`cod_serv` = $doc");

echo "<script> alert('Servicio eliminado correctamente.'); </script>";

}

if (isset($_POST['btn_modificar'])){

 echo "<script>window.location='dashboard.php?mod=gestion_servicios#formulario';</script>";

}
if (isset($_POST['btn_actualizar_servicio'])){
  // Traemos la conexion
include "conexion.php";

// Traemos todos los datos del formulario
$cod_s = $_POST['cs'];
$fe_ini = $_POST['fi'];
$fe_fin = $_POST['ff'];
$tip_s = $_POST['ts'];
$report_s = $_POST['rs'];
$des_s = $_POST['ds'];
$serv_c = $_POST['sc'];
$fk_usu = $_POST['id_usu'];


//Realizamos el envio a la tabla usuarios de la bd
$modificar = mysqli_query($conexion, "UPDATE `reporte_servicios` SET `cod_serv` = '$cod_s', `fecha_ini` = '$fe_ini', `fecha_fin` = '$fe_fin', `tipo_servicio` = '$tip_s', `reporte_servicios` = '$report_s', `descrip_serv` = '$des_s', `servicio_concre` = '$serv_c', `fk_usu_repor` = '$fk_usu' WHERE `reporte_servicios`.`cod_serv` = '$cod_s';") or die ($conexion."Error en el registro");


// Mostramos mensaje tipo alerta de registro exitoso
echo "<script>alert('Modificación Exitosa');</script>";


}

?>

<br><br>

  <form action="dashboard.php?mod=gestion_servicios" method="post">
    <input type="text" class="form-control" placeholder="Buscar por código del servicio" name="txtbuscar" style="width: 50%;">
    <button type="submit" class="btn btn-block mybtn btn-success tx-tfm" name="btn_registrar1" style="border-radius: 60px;
    background-color: #94D49F;
    width: 100px;
    margin-top: 8px;
    color: #010101;">Buscar</button>
  </form>

<br>
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title" style="text-align: center;">Gestión de Servicios</h4>
                  <center> <p class="card-description">
                    ¡Hola, <?php echo $_SESSION['nombre'];?>! 
                    Aquí puedes gestionar los servicios.
                  </p> </center>
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Código servicio</th>
                          <th>Fecha de Inicio </th>
                          <th>Fecha de Fin</th>
                          <th>Tipo de servicio</th>
                          <th>Reporte de servicio</th>
                          <th>Descripcion del servicio</th>
                          <th>Editar</th>
                          <th>Eliminar</th>
                        </tr>
                      </thead>

                      <tbody>
                      
<?php

//recibir el dato 
$dato = @$_POST['txtbuscar'];

// Consulta
$consulta = mysqli_query($conexion,"SELECT * FROM reporte_servicios WHERE cod_serv LIKE '%$dato%';") or die ($conexion."Error en la consulta");

//Cantidad de datos encontrados
$cantidad = mysqli_num_rows($consulta);
if($cantidad > 0){

// Ciclo para recorrer los datos
while($fila=mysqli_fetch_array($consulta)){
?>

<tr>
  <td> <?php echo $fila['cod_serv'];  ?></td>
  <td> <?php echo $fila['fecha_ini']; ?></td>
  <td> <?php echo $fila['fecha_fin']; ?></td>
  <td> <?php echo $fila['tipo_servicio']; ?></td>
  <td> <?php echo $fila['reporte_servicios']; ?></td>
  <td> <?php echo $fila['descrip_serv']; ?></td>
  <td>
      
    <form action="dashboard.php?mod=gestion_servicios" method="post">
      <input type="text" name="doc_modificar" value="<?php echo $fila['cod_serv']; ?>" hidden>
        <button type="submit" name="btn_modificar" style="background-color: rgba(0, 0, 0, 0.0); border: 0px;">
          <i class="fa-solid fa-pen-to-square" style="color:#94D49F;"></i>
        </button>
    </form>

  </td>
  <td>
    <form action="dashboard.php?mod=gestion_servicios" method="post">
      <input type="text" name="doc_eliminar" value="<?php echo $fila['cod_serv']; ?>" hidden>
      <input type="text" name="fecha" value="<?php echo date('Y-m-d H:i'); ?>" hidden>

        <button type="submit" name="btn_eliminar" style="background-color: rgba(0, 0, 0, 0.0); border: 0px;">
          <i class="fa-solid fa-trash" style="color: #94D49F; margin-left: 1rem;"></i>
        </button>
    </form>

  </td>
</tr>

<?php
    }
  }
}
?>

</tbody>
</table>

<?php
  if (isset($_POST['btn_modificar'])){

  $doc = @$_POST['doc_modificar'];

  // Consulta
  $consulta = mysqli_query($conexion,"SELECT * FROM reporte_servicios WHERE cod_serv = $doc");

  // Recolectamos todos los datos
  while($fila2=mysqli_fetch_array($consulta)){

?>

<div class="row">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">

      <div class="myform">

      <div class="titulo">
        <h4 class="card-title" style="text-align: center;">Modificar</h4>
      </div>

<form action="dashboard.php?mod=gestion_servicios" method="post" name="registration">

      <div class="form-group">
        <input type="text" name="id_usu" class="form-control" id="id_usu" placeholder="Número identificación" value="<?php echo $fila2['fk_usu_repor']; ?>" />
      </div>

      <div class="form-group">
        <input type="text" name="cs" class="form-control" id="cs" placeholder="Codigo servicio" value="<?php echo $fila2['cod_serv']; ?>" />
      </div>

      <div class="form-group">
        <span>Fecha de Inicio</span>
        <input type="date" name="fi" class="form-control campo_form" id="fi" placeholder="" value="<?php echo $fila2['fecha_ini']; ?>" />
      </div>

      <div class="form-group">
        <span>Fecha de Fin</span>
        <input type="date" name="ff" class="form-control campo_form" id="ff" placeholder="" value="<?php echo $fila2['fecha_fin']; ?>" />
      </div>

      <div class="form-group">
        <input type="text" name="ts" class="form-control" id="ts" placeholder="Tipo de servicio" value="<?php echo $fila2['tipo_servicio']; ?>" />
      </div>

      <div class="form-group">
        <input type="text" name="rs" id="rs" class="form-control" placeholder="Reporte de servicio" value="<?php echo $fila2['reporte_servicios']; ?>" />
      </div>

      <div class="form-group">
        <input type="text" name="ds" id="ds" class="form-control" placeholder="Descripción del servicio" value="<?php echo $fila2['descrip_serv']; ?>" />
      </div>

      <div class="form-group">
        <input type="text" name="sc" class="form-control" id="sc" placeholder="Servicio concretado" value="<?php echo $fila2['servicio_concre']; ?>" />
      </div>

      <div class="col-md-12 text-center mb-3">
        <button type="submit" class="btn btn-block mybtn btn-success tx-tfm" name="btn_actualizar_servicio" style="border-radius: 60px;
        background-color: #94D49F;
        width: 100px;
        margin-top: 8px;
        color: #010101;">Modificar</button>
      </div>
</form>

</div>
</div>
</div>
                          
<?php
}
}
?>

      </div>
    </div>
  </div>
</div>