
<head>
    <link rel="stylesheet" type="text/css" href="estilosreg.css" />
</head>
<body>
    <div class="wrapper">
        <section class="users">
            <header>
            <?php 
                include "conexion.php";

                $sql = mysqli_query($conexion, "SELECT * FROM usuario WHERE nu_id");
                if(mysqli_num_rows($sql) > 0){
                    $fila = mysqli_fetch_assoc($sql);
                }
                ?>
                <div class="content">
                    <img src="img/icono.png" alt="">
                    <div class="details">
                        <span><?php echo $_SESSION['nombre'] . " " . $_SESSION['apellido']?></span>
                        <p><?php echo $fila['status'] ?></p>
                    </div>
                </div>
                <a href="#" class="logout">Salir</a>
            </header>
            <div class="search">
                <span class="text">Selecciona un usuario para chatear</span>
                <input type="text" placeholder="Ingresa un nombre para buscar">
                <button><i class="fa-solid fa-magnifying-glass"></i></button>
            </div>
                    <div class="users-list">
                        
                         
            </div>
        </section>
    </div>
    <script src="js/users.js"></script>
