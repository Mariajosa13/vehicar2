<div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-6 grid-margin stretch-card"  style="height: 20rem">
              <div class="card">
                <div class="card-body">
                <div class="dropdown-header text-center">
                <h4 class="card-title">Manuela Pino Hincapié</h4>
                <img class="img-md rounded-circle" src="img/icono.png" alt="Profile image" style="height: 80px; weight:80px;"> <hr>
                <h6 style="text-align: center">Profesional en Veterinaria</h6>
                <h6 style="text-align: center">Medellín</h6>
                <h6 style="text-align: center">C.C 1.337.226.034</h6>
                <h6 style="text-align: center">manu78@gmail.com</h6>
              </div> 
                  <canvas id="lineChart"></canvas>
                </div>
              </div>
            </div>
            <div class="col-lg-6 grid-margin stretch-card"  style="height: 20rem">
              <div class="card">
                <div class="card-body">
                <div class="dropdown-header text-center">
                <h4 class="card-title">Maria Fernanda Acevedo Gimenez</h4>
                <img class="img-md rounded-circle" src="img/icono.png" alt="Profile image" style="height: 80px; weight:80px;"> <hr>
                <h6 style="text-align: center">Profesional en Veterinaria</h6>
                <h6 style="text-align: center">Medellín</h6>
                <h6 style="text-align: center">C.C 1.227.036.554</h6>
                <h6 style="text-align: center">fer23@gmail.com</h6>
              </div> 
                  <canvas id="barChart"></canvas>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
          <div class="col-lg-6 grid-margin stretch-card"  style="height: 20rem">
              <div class="card">
                <div class="card-body">
                <div class="dropdown-header text-center">
                <h4 class="card-title">Elvia Muñoz Acevedo</h4>
                <img class="img-md rounded-circle" src="img/icono.png" alt="Profile image" style="height: 80px; weight:80px;"> <hr>
                <h6 style="text-align: center">Profesional en Veterinaria</h6>
                <h6 style="text-align: center">Medellín</h6>
                <h6 style="text-align: center">C.C 1.007.456.298</h6>
                <h6 style="text-align: center">ElviaMunoz@gmail.com</h6>
              </div> 
                  <canvas id="areaChart"></canvas>
                </div>
              </div>
            </div>
            <div class="col-lg-6 grid-margin stretch-card"  style="height: 20rem">
              <div class="card">
                <div class="card-body">
                <div class="dropdown-header text-center">
                <h4 class="card-title">Lucía Torres Naranjo</h4>
                <img class="img-md rounded-circle" src="img/icono.png" alt="Profile image" style="height: 80px; weight:80px;"> <hr>
                <h6 style="text-align: center">Profesional en Veterinaria</h6>
                <h6 style="text-align: center">Medellín</h6>
                <h6 style="text-align: center">C.C 1.217.467.004</h6>
                <h6 style="text-align: center">luci22@gmail.com</h6>
              </div> 
                </div>
              </div>
            </div>
          </div>
          <div class="row">
          <div class="col-lg-6 grid-margin stretch-card"  style="height: 20rem">
              <div class="card">
                <div class="card-body">
                <div class="dropdown-header text-center">
                <h4 class="card-title">Isabel Giraldo Cardenas</h4>
                <img class="img-md rounded-circle" src="img/icono.png" alt="Profile image" style="height: 80px; weight:80px;"> <hr>
                <h6 style="text-align: center">Profesional en Veterinaria</h6>
                <h6 style="text-align: center">Medellín</h6>
                <h6 style="text-align: center">C.C 1.557.908.254</h6>
                <h6 style="text-align: center">67isabel@gmail.com</h6>
              </div> 
                  <canvas id="pieChart"></canvas>
                </div>
              </div>
            </div>
            <div class="col-lg-6 grid-margin stretch-card"  style="height: 20rem">
              <div class="card">
                <div class="card-body">
                <div class="dropdown-header text-center">
                <h4 class="card-title">Valeria Vásquez Hernandez</h4>
                <img class="img-md rounded-circle" src="img/icono.png" alt="Profile image" style="height: 80px; weight:80px;"> <hr>
                <h6 style="text-align: center">Profesional en Veterinaria</h6>
                <h6 style="text-align: center">Medellín</h6>
                <h6 style="text-align: center">C.C 1.467.890.764</h6>
                <h6 style="text-align: center">valvas567@gmail.com</h6>
              </div> 
                  <canvas id="scatterChart"></canvas>
                </div>
              </div>
            </div>
          </div>
        </div>