<?php
// Incluir la conexion
include './conexion.php';

// Verificar el boton buscar
if(isset($_SESSION['nu_id'])){

if (isset($_POST['btn_eliminar'])){

$doc = $_POST['doc_eliminar'];

$eliminar = mysqli_query($conexion,"DELETE FROM histo_document WHERE `histo_document`.`cod_archivo` = $doc");

echo "<script> alert('Documento eliminado correctamente.'); </script>";

}

if (isset($_POST['btn_modificar'])){

 echo "<script>window.location='dashboard.php?mod=modificar_archivos#formulario';</script>";

}
if (isset($_POST['btn_actualizar_archivo'])){
  // Traemos la conexion
include "conexion.php";

// Traemos todos los datos del formulario
$cod_a = $_POST['ca'];
$fe_sub = $_POST['fs'];
$tip_a = $_POST['ta'];
$nom_a = $_POST['na'];
$des_a = $_POST['da'];
$n_id = $_POST['nu_id'];


//Realizamos el envio a la tabla usuarios de la bd
$modificar = mysqli_query($conexion,"UPDATE `histo_document` SET `cod_archivo` = '$cod_a', `fecha_subida` = '$fe_sub', `tip_arch` = '$tip_a', `nomb_arch` = '$nom_a', `descripci_arch` = '$des_a', `fk_usu_histo` = '$n_id' WHERE `histo_document`.`cod_archivo` = '$cod_a';") or die ($conexion."Error en el registro");


// Mostramos mensaje tipo alerta de registro exitoso
echo "<script>alert('Modificación Exitosa');</script>";


}  
?>

<br><br>

  <form action="dashboard.php?mod=modificar_archivos" method="post">
    <input type="text" class="form-control" placeholder="Buscar por código del servicio" name="txtbuscar" style="width: 50%;">
    <button type="submit" class="btn btn-block mybtn btn-success tx-tfm" name="btn_registrar1" style="border-radius: 60px;
    background-color: #94D49F;
    width: 100px;
    margin-top: 8px;
    color: #010101;">Buscar</button>
  </form>

<br>
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title" style="text-align: center;">Gestión de documentos</h4>
                  <center> <p class="card-description">
                    ¡Hola, <?php echo $_SESSION['nombre'];?>! 
                    Aquí puedes gestionar los servicios.
                  </p> </center>
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Código del archivo</th>
                          <th>Fecha de subida</th>
                          <th>Tipo de archivo</th>
                          <th>Nombre del archivo</th>
                          <th>Descripción del archivo</th>
                          <th>Editar</th>
                          <th>Eliminar</th>
                        </tr>
                      </thead>

                      <tbody>
                      
<?php
//recibir el dato
 
$dato = @$_POST['txtbuscar'];

// Consulta
$consulta = mysqli_query($conexion,"SELECT * FROM histo_document WHERE cod_archivo LIKE '%$dato%';") or die ($conexion."Error en la consulta");

//Cantidad de datos encontrados
$cantidad = mysqli_num_rows($consulta);
if($cantidad > 0){

// Ciclo para recorrer los datos
while($fila=mysqli_fetch_array($consulta)){
?>

<tr>
  <td> <?php echo $fila['cod_archivo'];  ?></td>
  <td> <?php echo $fila['fecha_subida']; ?></td>
  <td> <?php echo $fila['tip_arch']; ?></td>
  <td> <?php echo $fila['nomb_arch']; ?></td>
  <td> <?php echo $fila['descripci_arch']; ?></td>
  <td>
      
    <form action="dashboard.php?mod=modificar_archivos" method="post">
      <input type="text" name="doc_modificar" value="<?php echo $fila['cod_archivo']; ?>" hidden>
        <button type="submit" name="btn_modificar" style="background-color: rgba(0, 0, 0, 0.0); border: 0px;">
          <i class="fa-solid fa-pen-to-square" style="color:#94D49F;"></i>
        </button>
    </form>

  </td>
  <td>
    <form action="dashboard.php?mod=modificar_archivos" method="post">
      <input type="text" name="doc_eliminar" value="<?php echo $fila['cod_archivo']; ?>" hidden>
      <input type="text" name="fecha" value="<?php echo date('Y-m-d'); ?>" hidden>

        <button type="submit" name="btn_eliminar" style="background-color: rgba(0, 0, 0, 0.0); border: 0px;">
          <i class="fa-solid fa-trash" style="color: #94D49F; margin-left: 1rem;"></i>
        </button>
    </form>

  </td>
</tr>

<?php
    }
  }
}
?>

</tbody>
</table>

<?php
  if (isset($_POST['btn_modificar'])){

  $doc = @$_POST['doc_modificar'];

  // Consulta
  $consulta = mysqli_query($conexion,"SELECT * FROM histo_document WHERE cod_archivo = $doc");

  // Recolectamos todos los datos
  while($fila2=mysqli_fetch_array($consulta)){

?>

<div class="row">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">

      <div class="myform">

      <div class="titulo">
        <h4 class="card-title" style="text-align: center;">Modificar</h4>
      </div>

<form action="dashboard.php?mod=modificar_archivos" method="post" name="registration">

      <div class="form-group">
        <input type="text" name="nu_id" class="form-control" id="nu_id" placeholder="Número de identificación" value="<?php echo $fila2['fk_usu_histo']; ?>" />
      </div>

      <div class="form-group">
        <input type="text" name="ca" class="form-control" id="ca" placeholder="Código archivo" value="<?php echo $fila2['cod_archivo']; ?>" />
      </div>

      <div class="form-group">
        <span>Fecha subida</span>
        <input type="date" name="fs" class="form-control campo_form" id="fs" placeholder="Fecha subida" value="<?php echo $fila2['fecha_subida']; ?>" />
      </div>

      <div class="form-group">
        <input type="text" name="ta" class="form-control" id="ta" placeholder="Tipo de archivo" value="<?php echo $fila2['tip_arch']; ?>" />
      </div>

      <div class="form-group">
        <input type="text" name="na" id="na" class="form-control" placeholder="Nombre archivo" value="<?php echo $fila2['nomb_arch']; ?>" />
      </div>

      <div class="form-group">
        <input type="text" name="da" id="da" class="form-control" placeholder="Descripción archivo" value="<?php echo $fila2['descripci_arch']; ?>" />
      </div>

      <div class="col-md-12 text-center mb-3">
        <button type="submit" class="btn btn-block mybtn btn-success tx-tfm" name="btn_actualizar_archivo" style="border-radius: 60px;
        background-color: #94D49F;
        width: 100px;
        margin-top: 8px;
        color: #010101;">Modificar</button>
      </div>
</form>

</div>
</div>
</div>
                          
<?php
}
}
?>

      </div>
    </div>
  </div>
</div>