<!-- Crear usuarios -->
    
<div class="row" style="margin-left:20%;">
            <div class="col-md-8 grid-margin stretch-card" style="margin-right:20%;">
              <div class="card" style="display: flex; flex-direction: column; justify-content: center; align-items: center;">
                <div class="card-body">
                  <div class="myform">

            <div class="titulo">
              <h4 class="card-title" style="text-align: center;">Crear usuario</h4>
              <center> <p class="card-description">
                    ¡Hola, <?php echo $_SESSION['nombre'];?>! 
                    Aquí puedes crear usuarios.
                  </p> </center>
            </div>  

          <form action="registrar.php" method="post" name="registration">

            <div class="base col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12" style="column-count: 2;">

              <div class="form-group">
                <input type="text" name="nombre1" class="form-control" id="nombre1" placeholder="Primer nombre" required />
              </div>

              <div class="form-group">
                <input type="text" name="nombre2" class="form-control" id="nombre2" placeholder="Segundo nombre" />
              </div>

              <div class="form-group">
                <input type="text" name="apellido1" class="form-control" id="apellido1" placeholder="Primer apellido" required />
              </div>

              <div class="form-group">
                <input type="text" name="apellido2" class="form-control" id="apellido2" placeholder="Segundo apellido" required />
              </div>

              <div class="form-group">
                <input type="text" name="Nid" class="form-control" id="Nid" placeholder="Número de identificación" required />
              </div>

             <div class="form-group"> 
                <input type="text" name="Tipo" class="form-control" id="Tid" placeholder="Tipo de identificación" required />
              </div> 
              

            </div>

            <div class="base col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12" style="column-count:2;">
              <div class="form-group">
                <span style="font-size:15px;">Fecha de nacimiento</span>
                <input type="date" name="FN" class="form-control campo_form" id="FN" placeholder="Fecha de nacimiento" required />
              </div>

              <div class="form-group">
                <input type="text" name="Cr" class="form-control" id="Cr" placeholder="Ciudad de residencia" required />
              </div>

              <div class="form-group">
                <input type="text" name="NT" class="form-control" id="NT" placeholder="Número de teléfono" required />
              </div>

              <div class="form-group">
                <span style="color: white;">...</span>
                <input type="email" name="email" class="form-control" id="email" placeholder="Correo electrónico" required />
              </div>

              <div class="form-group">
                <input type="password" name="password1" id="password1" class="form-control" placeholder="Contraseña" required />
              </div>

              <div class="form-group">
                <input type="password" name="password2" id="password2" class="form-control" placeholder="Confirmar contraseña" required />
              </div>
            </div>

            <div class="col-md-12 text-center mb-3" style="justify-content: center;">
              <button type="submit" class="btn btn-block mybtn btn-success tx-tfm" name="btn_registrar1" style="border-radius: 60px;
  background-color: #94D49F;
  width: 100px;
  margin-top: 8px;
  color: #010101;">Aceptar</button>
            </div>

          </form>

</div>
</div>
    