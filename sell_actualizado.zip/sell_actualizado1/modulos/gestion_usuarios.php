<?php
// Incluir la conexion
include './conexion.php';

// Verificar el boton buscar
if(isset($_SESSION['nu_id'])){

if (isset($_POST['btn_eliminar'])){

$doc = $_POST['doc_eliminar'];

$eliminar = mysqli_query($conexion,"DELETE FROM usuario WHERE `usuario`.`nu_id` = $doc");

echo "<script> alert('Usuario eliminado correctamente.'); </script>";

}

if (isset($_POST['btn_modificar'])){

 echo "<script>window.location='dashboard.php?mod=gestion_usuarios#formulario';</script>";

}
if (isset($_POST['btn_actualizar_usuario'])){
  // Traemos la conexion
include "conexion.php";

// Traemos todos los datos del formulario
$num_id = $_POST['Nid'];
$ti_id = $_POST['Tipo'];
$nomb_1 = $_POST['nombre1'];
$nomb_2 = $_POST['nombre2'];
$apel_1 = $_POST['apellido1'];
$apel_2 = $_POST['apellido2'];
$f_date = $_POST['FN'];
$ciu_resi = $_POST['Cr'];
$num_tel = $_POST['NT'];
$email = $_POST['email'];
$rol = $_POST['rol'];


//Realizamos el envio a la tabla usuarios de la bd
$modificar = mysqli_query($conexion,"UPDATE `usuario` SET `nu_id` = '$num_id', `tip_id` = '$ti_id', `nom_1` = '$nomb_1', `nom_2` = '$nomb_2', `ape_1` = '$apel_1', `ape_2` = '$apel_2', `date` = '$f_date', `ciu_re` = '$ciu_resi', `num_te` = '$num_tel', `email` = '$email', `fk_rol_usu` = '$rol' WHERE `usuario`.`nu_id` = '$num_id';") or die ($conexion."Error en el registro");


// Mostramos mensaje tipo alerta de registro exitoso
echo "<script>alert('Modificación Exitosa');</script>";


}

?>

<br><br>
      <!-- partial -->
  <form action="dashboard.php?mod=gestion_usuarios" method="post">
  <input type="text" class="form-control" placeholder="Buscar por nombre" name="txtbuscar" style="width: 50%;">
  <button type="submit" class="btn btn-block mybtn btn-success tx-tfm" name="btn_registrar1" style="border-radius: 60px;
  background-color: #94D49F;
  width: 100px;
  margin-top: 8px;
  color: #010101;">Buscar</button>
</form>
<br>
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title" style="text-align: center;">Gestión de usuarios</h4>
                  <center> <p class="card-description">
                    ¡Hola, <?php echo $_SESSION['nombre'];?>! 
                    Aquí puedes gestionar los usuarios.
                  </p> </center>
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Tipo de documento</th>
                          <th>Número de documento</th>
                          <th>Primer Nombre</th>
                          <th>Primer apellido</th>
                          <th>Correo</th>
                          <th>Editar</th>
                          <th>Eliminar</th>
                        </tr>
                      </thead>
                      <tbody>
              
<?php

 //recibir el dato
 $dato = @$_POST['txtbuscar'];

 // Consulta
 $consulta = mysqli_query($conexion,"SELECT * FROM usuario WHERE nom_1 LIKE '%$dato%';") or die ($conexion."Error en la consulta");

//Cantidad de datos encontrados
 $cantidad = mysqli_num_rows($consulta);
 if($cantidad > 0){

  // Ciclo para recorrer los datos
 while($fila=mysqli_fetch_array($consulta)){
  ?>

      <tr>
      <td><?php echo $fila['tip_id'];  ?></td>
      <td><?php echo $fila['nu_id']; ?></td>
      <td><?php echo $fila['nom_1']; ?></td>
      <td><?php echo $fila['ape_1']; ?></td>
      <td><?php echo $fila['email']; ?></td>
      <td>

      <form action="dashboard.php?mod=gestion_usuarios" method="post">
          <input type="text" name="doc_modificar" value="<?php echo $fila['nu_id']; ?>" hidden>
            <button type="submit" name="btn_modificar" style="background-color: rgba(0, 0, 0, 0.0); border: 0px;">
            <i class="fa-solid fa-pen-to-square" style="color:#94D49F;"></i>
            </button>
        </form>

      </td>
      <td>
      <form action="dashboard.php?mod=gestion_usuarios" method="post">
          <input type="text" name="doc_eliminar" value="<?php echo $fila['nu_id']; ?>" hidden>
          <input type="text" name="fecha" value="<?php echo date('Y-m-d'); ?>" hidden>

            <button type="submit" name="btn_eliminar" style="background-color: rgba(0, 0, 0, 0.0); border: 0px;">
            <i class="fa-solid fa-trash" style="color: #94D49F; margin-left: 1rem;"></i>
          </button>
        </form>

      </td>
    </tr>

<?php
    }
  }
}
  ?>
 
  </tbody>
  </table>

<?php
  if (isset($_POST['btn_modificar'])){

  $doc = @$_POST['doc_modificar'];

  // Consulta
  $consulta = mysqli_query($conexion,"SELECT * FROM usuario WHERE nu_id = $doc");

  // Recolectamos todos los datos
  while($fila2=mysqli_fetch_array($consulta)){

?>

<div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
<div class="myform">

<div class="titulo">
<h4 class="card-title" style="text-align: center;">Modificar</h4>
</div>

<form action="dashboard.php?mod=gestion_usuarios" method="post" name="registration">

<div class="form-group"> 
    <input type="text" name="Tipo" class="form-control" id="Tid" placeholder="Tipo de identificación" value="<?php echo $fila2['tip_id']; ?>"/>
  </div> 

<div class="form-group">
    <input type="text" name="Nid" class="form-control" id="Nid" placeholder="Número de identificación" value="<?php echo $fila2['nu_id']; ?>"/>
  </div>

  <div class="form-group">
    <input type="text" name="nombre1" class="form-control" id="nombre1" placeholder="Primer nombre" value="<?php echo $fila2['nom_1']; ?>"/>
  </div>

  <div class="form-group">
    <input type="text" name="nombre2" class="form-control" id="nombre2" placeholder="Segundo nombre" value="<?php echo $fila2['nom_2']; ?>"/>
    </div>

  <div class="form-group">
    <input type="text" name="apellido1" class="form-control" id="apellido1" placeholder="Primer apellido" value="<?php echo $fila2['ape_1']; ?>"/>
  </div>

  <div class="form-group">
      <input type="text" name="apellido2" class="form-control" id="apellido2" placeholder="Segundo apellido"  value="<?php echo $fila2['ape_2']; ?>"/>
    </div>

    <div class="form-group">
      <input type="date" name="FN" class="form-control campo_form" id="FN" placeholder="Fecha de nacimiento" value="<?php echo $fila2['date']; ?>" />
    </div>

  <div class="form-group">
    <input type="email" name="email" class="form-control" id="email" placeholder="Correo electrónico" value="<?php echo $fila2['email']; ?>"/>
  </div>

  <div class="form-group">
    <input type="text" name="Cr" class="form-control" id="Cr" placeholder="Ciudad de residencia"  value="<?php echo $fila2['ciu_re']; ?>"/>
  </div>

  <div class="form-group">
    <input type="text" name="NT" class="form-control" id="NT" placeholder="Número de teléfono" value="<?php echo $fila2['num_te']; ?>" />
  </div>

  <div class="form-group">
    <input type="password" name="password1" id="password1" class="form-control" placeholder="Contraseña" value="<?php echo $fila2['pass']; ?>" />
  </div>

  <div class="form-group">
    <input type="password" name="password2" id="password2" class="form-control" placeholder="Confirmar contraseña" value="<?php echo $fila2['pass_c']; ?>" />
  </div>

  <div class="form-group">
    <input type="text" name="rol" id="rol" class="form-control" placeholder="Rol" value="<?php echo $fila2['fk_rol_usu']; ?>" />

  </div>

<div class="col-md-12 text-center mb-3">
  <button type="submit" class="btn btn-block mybtn btn-success tx-tfm" name="btn_actualizar_usuario" style="border-radius: 60px;
  background-color: #94D49F;
  width: 100px;
  margin-top: 8px;
  color: #010101;">Modificar</button>
</div>
</form>

</div>
</div>
</div>
                          
<?php
}
}
?>