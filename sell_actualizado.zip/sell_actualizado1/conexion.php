<?php

$conexion = mysqli_connect("localhost", "root", "", "sellwork") or die("Error en la conexion");
$conexion->set_charset("utf8");
?>