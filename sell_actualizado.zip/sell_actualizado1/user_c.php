<?php  
    session_start();
    include_once "conexion.php";
    $sql = mysqli_query($conexion, "SELECT * FROM usuario");
    $output = "";
    if (mysqli_num_rows(sql) == 1) {
        $output _= "No hay usuarios para chatear";
    }elseif (mysqli_num_rows(sql) > 0) {
        while($fila = mysqli_fetch_assoc($sql)){
            $output _= '<a href="#">
                        <img src="img/icono.png" alt="">
                        <div class="details">
                        <span>'. $_SESSION['nombre'] .'</span>
                        <p>This is test message</p>
                        </div>
                        <div class="status-dot">
                        <i class="fa-solid fa-circle-dot" ></i>
                        </div>
                        </div>
    
                        </a>';
        }
    }

    echo $ouput;
?>