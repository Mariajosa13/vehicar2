-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 02-08-2023 a las 17:19:56
-- Versión del servidor: 10.4.17-MariaDB
-- Versión de PHP: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sellwork`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `chatbot`
--

CREATE TABLE `chatbot` (
  `id` int(11) NOT NULL,
  `queries` varchar(300) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `replies` varchar(300) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `fk_chat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `formacion_acade`
--

CREATE TABLE `formacion_acade` (
  `cod_curs` varchar(40) COLLATE utf8_spanish2_ci NOT NULL,
  `fecha_ini_curso` datetime NOT NULL,
  `fecha_fin_curso` datetime NOT NULL,
  `tipo_curso` varchar(60) COLLATE utf8_spanish2_ci NOT NULL,
  `descripcion_curso` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `formacion_academica` varchar(15) COLLATE utf8_spanish2_ci NOT NULL,
  `fk_usuario` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `histo_document`
--

CREATE TABLE `histo_document` (
  `cod_archivo` varchar(40) COLLATE utf8_spanish2_ci NOT NULL,
  `fecha_subida` datetime NOT NULL,
  `tip_arch` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  `nomb_arch` varchar(60) COLLATE utf8_spanish2_ci NOT NULL,
  `descripci_arch` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `fk_usu_histo` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reporte_servicios`
--

CREATE TABLE `reporte_servicios` (
  `cod_serv` varchar(40) COLLATE utf8_spanish2_ci NOT NULL,
  `fecha_ini` datetime NOT NULL,
  `fecha_fin` datetime NOT NULL,
  `tipo_servicio` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `reporte_servicios` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  `descrip_serv` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `servicio_concre` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  `fk_usu_repor` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

CREATE TABLE `rol` (
  `ti_rol` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  `id_rol` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`ti_rol`, `id_rol`, `descrip`) VALUES
('3', 'Administrador', ''),
('2', 'Cliente', ''),
('1', 'Vendedor', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `nu_id` int(20) NOT NULL,
  `tip_id` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  `nom_1` varchar(60) COLLATE utf8_spanish2_ci NOT NULL,
  `nom_2` varchar(60) COLLATE utf8_spanish2_ci NOT NULL,
  `ape_1` varchar(60) COLLATE utf8_spanish2_ci NOT NULL,
  `ape_2` varchar(60) COLLATE utf8_spanish2_ci NOT NULL,
  `date` date NOT NULL,
  `ciu_re` varchar(40) COLLATE utf8_spanish2_ci NOT NULL,
  `num_te` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `pass` varchar(101) COLLATE utf8_spanish2_ci NOT NULL,
  `pass_c` varchar(101) COLLATE utf8_spanish2_ci NOT NULL,
  `fk_rol_usu` varchar(100) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`nu_id`, `tip_id`, `nom_1`, `nom_2`, `ape_1`, `ape_2`, `date`, `ciu_re`, `num_te`, `email`, `pass`, `pass_c`, `fk_rol_usu`) VALUES
(0, 'TI', 'Administrador', '', 'Administrador', 'Administrador', '2023-06-06', 'Medellín', '3000000000', 'admin@gmail.com', '0192023a7bbd73250516f069df18b500', '0192023a7bbd73250516f069df18b500', 'Administrador'),
(101, 'CC', 'Felick', 'Hernesto', 'Mejia', 'Cadena', '2023-05-28', 'Medellín', '56789', 'aa@gmail.com', 'caf1a3dfb505ffed0d024130f58c5cfa', 'caf1a3dfb505ffed0d024130f58c5cfa', 'Cliente'),
(123, 'ti', 'Felick', 'Hernesto', 'Mejia', 'Cadena', '2023-06-01', 'Medellín', '111', 'd@gmail.com', '698d51a19d8a121ce581499d7b701668', '698d51a19d8a121ce581499d7b701668', 'Cliente'),
(1236, 'cc', 'julia', '', 'rodriguez', 'toro', '2000-12-14', 'Bogotá', '5678', 'julia@gmail.com', 'def7924e3199be5e18060bb3e1d547a7', 'def7924e3199be5e18060bb3e1d547a7', 'Cliente'),
(567890, 'ti', 'Felick', 'Hernesto', 'Mejia', 'Cadena', '2023-05-31', 'Medellín', '56789', 'k@gmail.com', '698d51a19d8a121ce581499d7b701668', '698d51a19d8a121ce581499d7b701668', 'Cliente'),
(10123405, 'ti', 'Juan', 'Carlos', 'Gonzales', 'Ramirez', '2020-11-19', 'Bogotá', '12345', '1234@gmail.com', '250cf8b51c773f3f8dc8b4be867a9a02', '250cf8b51c773f3f8dc8b4be867a9a02', 'Cliente');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `chatbot`
--
ALTER TABLE `chatbot`
  ADD PRIMARY KEY (`id`),
  ADD KEY `restriccionchat` (`fk_chat`);

--
-- Indices de la tabla `formacion_acade`
--
ALTER TABLE `formacion_acade`
  ADD PRIMARY KEY (`cod_curs`),
  ADD KEY `restriccion1` (`fk_usuario`);

--
-- Indices de la tabla `histo_document`
--
ALTER TABLE `histo_document`
  ADD PRIMARY KEY (`cod_archivo`),
  ADD KEY `restriccion3` (`fk_usu_histo`);

--
-- Indices de la tabla `reporte_servicios`
--
ALTER TABLE `reporte_servicios`
  ADD PRIMARY KEY (`cod_serv`),
  ADD KEY `restriccion2` (`fk_usu_repor`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`id_rol`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`nu_id`),
  ADD KEY `restriccion4` (`fk_rol_usu`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `chatbot`
--
ALTER TABLE `chatbot`
  ADD CONSTRAINT `restriccionchat` FOREIGN KEY (`fk_chat`) REFERENCES `usuario` (`nu_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `formacion_acade`
--
ALTER TABLE `formacion_acade`
  ADD CONSTRAINT `restriccion1` FOREIGN KEY (`fk_usuario`) REFERENCES `usuario` (`nu_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `histo_document`
--
ALTER TABLE `histo_document`
  ADD CONSTRAINT `restriccion3` FOREIGN KEY (`fk_usu_histo`) REFERENCES `usuario` (`nu_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `reporte_servicios`
--
ALTER TABLE `reporte_servicios`
  ADD CONSTRAINT `restriccion2` FOREIGN KEY (`fk_usu_repor`) REFERENCES `usuario` (`nu_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `restriccion4` FOREIGN KEY (`fk_rol_usu`) REFERENCES `rol` (`id_rol`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
