<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8" />

    <!-- CSS only -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65"
      crossorigin="anonymous"
    />

    <!-- JavaScript Bundle with Popper -->
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4"
      crossorigin="anonymous"
    ></script>

    <!--CSS Propio-->
    <link rel="stylesheet" type="text/css" href="estilosreg.css" />

    <!--Favicon-->
    <link rel="icon" type="image/jpg" href="img/favicon.png" />

    <title>Registrarse - Sell & Work</title>
  </head>

  <body>
    <center>
        <div class="myform">

            <div class="titulo">
              <h1>Registrarse</h1>
            </div>

            <div class="logo">
              <img src="img/logo.png" class="logo" alt="Logo" />
            </div>

          <form action="registrar.php" method="post" name="registration">

            <div class="base col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12">

              <div class="form-group">
                <input type="text" name="nombre1" class="form-control" id="nombre1" placeholder="Primer nombre" required />
              </div>

              <div class="form-group">
                <input type="text" name="nombre2" class="form-control" id="nombre2" placeholder="Segundo nombre" />
              </div>

              <div class="form-group">
                <input type="text" name="apellido1" class="form-control" id="apellido1" placeholder="Primer apellido" required />
              </div>

              <div class="form-group">
                <input type="text" name="apellido2" class="form-control" id="apellido2" placeholder="Segundo apellido" required />
              </div>

              <div class="form-group">
                <input type="text" name="Nid" class="form-control" id="Nid" placeholder="Número de identificación" required />
              </div>

             <div class="form-group"> 
                <input type="text" name="Tipo" class="form-control" id="Tid" placeholder="Tipo de identificación" required />
              </div> 
              
             <!--  <div class="form-group">
                <select class="campo_form" name="tipo_usu" id="Select1" required>
                  <option>Tipo de usuario</option>
                  <option values="CC">Cédula de ciudadanía</option>
                  <option values="CE">Cédula de extranjería</option>
                  <option values="PP">Pasaporte</option>
                  <option values="PEP">Permiso especial de permanencia</option>
                </select>
              </div> -->

            </div>

            <div class="base col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="form-group">
                <input type="date" name="FN" class="form-control campo_form" id="FN" placeholder="Fecha de nacimiento" required />
              </div>

              <div class="form-group">
                <input type="text" name="Cr" class="form-control" id="Cr" placeholder="Ciudad de residencia" required />
              </div>

              <div class="form-group">
                <input type="text" name="NT" class="form-control" id="NT" placeholder="Número de teléfono" required />
              </div>

              <div class="form-group">
                <input type="email" name="email" class="form-control" id="email" placeholder="Correo electrónico" required />
              </div>

              <div class="form-group">
                <input type="password" name="password1" id="password1" class="form-control" placeholder="Contraseña" required />
              </div>

              <div class="form-group">
                <input type="password" name="password2" id="password2" class="form-control" placeholder="Confirmar contraseña" required />
              </div>
            </div>

            <div class="col-md-12 text-center mb-3">
              <button type="submit" class="btn btn-block mybtn btn-success tx-tfm" name="btn_registrar1">Ingresar</button>
            </div>

          </form>

            <div class="hipervinculo">
              <p class="text-center">
                <a href="index.php" id="signin">¿Ya tienes una cuenta?</a>
              </p>
            </div>
</div>
</div>

            <?php
                //la informacion solo se envia si le das al boton. if (condicion) (isset (para verificar) ($_POST (metodo de envio mas seguro) ['btn_registrar'] (nombre del boton en el form)))
        
                if(isset($_POST['btn_registrar1'])){

   // llamar a la conexion de otro archivo (poner el nombre del otro archivo php)
   include ("conexion.php");


   //llamado de las variables ej: $nom_1 (nombre inventado) = $_POST (metodo de envio) ['nombre1'] (nombre en el formulario); 
   $num_id = $_POST['Nid'];
   $ti_id = $_POST['Tipo'];
   $nomb_1 = $_POST['nombre1'];
   $nomb_2 = $_POST['nombre2'];
   $apel_1 = $_POST['apellido1'];
   $apel_2 = $_POST['apellido2'];
   $f_date = $_POST['FN'];
   $ciu_resi = $_POST['Cr'];
   $num_tel = $_POST['NT'];
   $email = $_POST['email'];
   $pass1 = $_POST['password1'];
   $pass_con = $_POST['password2'];

   //Encriptamos la contraseña
   if ($_POST["$pass1"]==$_POST["$pass_con"]){

    $encrip = md5($pass_con);
  
   //registrar los datos en la tabla $registrar (variable)= mysqli_query (para insertar codigo de mysql) ($conexion (variable), "insert into usuario (nombre de la tabla) (nombres de los campos en phpmyadmin) values (nombre de las variables)")
   $registrar = mysqli_query($conexion,"INSERT INTO `usuario` (`nu_id`, `tip_id`, `nom_1`, `nom_2`, `ape_1`, `ape_2`, `date`, `ciu_re`, `num_te`, `email`, `pass`, `pass_c`, `fk_rol_usu`) VALUES ('$num_id', '$ti_id', '$nomb_1', '$nomb_2', '$apel_1', '$apel_2', '$f_date', '$ciu_resi', $num_tel, '$email', '$encrip', '$encrip', 'Cliente');");

   echo "<script> alert('Registro exitoso'); </script>";

   echo "<script> window.location='index.php'; </script>";
    } 
}

?>


        </div>
    </center>
  </body>
</html>
