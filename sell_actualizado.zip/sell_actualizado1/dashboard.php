<?php
//Abrimos la sesion
session_start();
if(!isset($_SESSION['nu_id'])){
 echo "<script> window.location='index.php'; </script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>SELL&WORK </title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/feather/feather.css">
  <link rel="stylesheet" href="vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="vendors/typicons/typicons.css">
  <link rel="stylesheet" href="vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="vendors/datatables.net-bs4/dataTables.bootstrap4.css">
  <link rel="stylesheet" href="js/select.dataTables.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/vertical-layout-light/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="img/favicon.png" />
</head>
<body>


  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="vendors/chart.js/Chart.min.js"></script>
  <script src="vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
  <script src="vendors/progressbar.js/progressbar.min.js"></script>

  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/jquery.cookie.js" type="text/javascript"></script>
  <script src="js/dashboard.js"></script>
  <script src="js/Chart.roundedBarCharts.js"></script>
  <script src="https://kit.fontawesome.com/41bcea2ae3.js" crossorigin="anonymous"></script>
  <!-- End custom js for this page-->
</body>
<div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex align-items-top flex-row">
      
      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-start">
        <div class="me-3">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-bs-toggle="minimize">
            <span class="icon-menu"></span>
          </button>
        </div>
        <div>
       
          <a class="navbar-brand brand-logo" href="dashboard.php" class="nav-item">
            <img src="img/sell.png" alt="logo" style="width: 1000px; height: 80px;"/>
          </a>
          <a class="navbar-brand brand-logo-mini" href="dashboard.php">
            <img src="img/favicon.png" alt="logo" />
          </a>
        </div>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-top" > 
        
        <ul class="navbar-nav ms-auto">
          <li class="nav-item dropdown d-none d-lg-block">
          
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list pb-0" aria-labelledby="messageDropdown">
              <a class="dropdown-item py-3" >
                <p class="mb-0 font-weight-medium float-left">Select category</p>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-item-content flex-grow py-2">
                  <p class="preview-subject ellipsis font-weight-medium text-dark">Bootstrap Bundle </p>
                  <p class="fw-light small-text mb-0">This is a Bundle featuring 16 unique dashboards</p>
                </div>
              </a>
              <a class="dropdown-item preview-item">
                <div class="preview-item-content flex-grow py-2">
                  <p class="preview-subject ellipsis font-weight-medium text-dark">Angular Bundle</p>
                  <p class="fw-light small-text mb-0">Everything you’ll ever need for your Angular projects</p>
                </div>
              </a>
              <a class="dropdown-item preview-item">
                <div class="preview-item-content flex-grow py-2">
                  <p class="preview-subject ellipsis font-weight-medium text-dark">VUE Bundle</p>
                  <p class="fw-light small-text mb-0">Bundle of 6 Premium Vue Admin Dashboard</p>
                </div>
              </a>
              <a class="dropdown-item preview-item">
                <div class="preview-item-content flex-grow py-2">
                  <p class="preview-subject ellipsis font-weight-medium text-dark">React Bundle</p>
                  <p class="fw-light small-text mb-0">Bundle of 8 Premium React Admin Dashboard</p>
                </div>
              </a>
            </div>
          </li>
          <li class="nav-item d-none d-lg-block">
            <div id="datepicker-popup" class="input-group date datepicker navbar-date-picker">
              <span class="input-group-addon input-group-prepend border-right">
                <span class="icon-calendar input-group-text calendar-icon"></span>
              </span>
              <input type="text" class="form-control">
            </div>
          </li>
          <li class="nav-item">
            <form class="search-form" action="#">
              <i class="icon-search"></i>
              <input type="search" class="form-control" placeholder="Buscar" title="Search here">
            </form>
          </li>
         
         
          <li class="nav-item dropdown d-none d-lg-block user-dropdown">
            <a class="nav-link" id="UserDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">
              <img class="img-xs rounded-circle" src="img/icono.png" alt="Profile image"> </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
              <div class="dropdown-header text-center">
                <img class="img-md rounded-circle" src="img/icono.png" alt="Profile image" style="height: 30px; weight:30px;">
                <p class="mb-1 mt-3 font-weight-semibold"><?php echo $_SESSION['nombre'];?></h1></p>
                <p class="fw-light text-muted mb-0"><?php echo $_SESSION['nu_id'];?></h1></p>
              </div>
              <a class="dropdown-item" href="dashboard.php?mod=miperfil"><i class="dropdown-item-icon mdi mdi-account-outline me-2" style="color: #4f7344;"></i> Mi perfil <span class="badge badge-pill badge-danger">1</span></a>
              <a class="dropdown-item"><i class="dropdown-item-icon mdi mdi-message-text-outline me-2 color=#4f7344" style="color: #4f7344;"></i> Mensajes </a>
              <a class="dropdown-item" href="salir.php"><i class="dropdown-item-icon mdi mdi-power me-2" style="color: #4f7344;"></i>Salir</a>
            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-bs-toggle="offcanvas">
          <span class="mdi mdi-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_settings-panel.html -->
      
      <div id="right-sidebar" class="settings-panel">
        <i class="settings-close ti-close"></i>
        <ul class="nav nav-tabs border-top" id="setting-panel" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" id="todo-tab" data-bs-toggle="tab" href="#todo-section" role="tab" aria-controls="todo-section" aria-expanded="true">TO DO LIST</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" id="chats-tab" data-bs-toggle="tab" href="#chats-section" role="tab" aria-controls="chats-section">CHATS</a>
          </li>
        </ul>
        <div class="tab-content" id="setting-content">
          <div class="tab-pane fade show active scroll-wrapper" id="todo-section" role="tabpanel" aria-labelledby="todo-section">
            <div class="add-items d-flex px-3 mb-0">
              <form class="form w-100">
                <div class="form-group d-flex">
                  <input type="text" class="form-control todo-list-input" placeholder="Add To-do">
                  <button type="submit" class="add btn btn-primary todo-list-add-btn" id="add-task">Add</button>
                </div>
              </form>
            </div>
            <div class="list-wrapper px-3">
              <ul class="d-flex flex-column-reverse todo-list">
                <li>
                  <div class="form-check">
                    <label class="form-check-label">
                      <input class="checkbox" type="checkbox">
                      Team review meeting at 3.00 PM
                    </label>
                  </div>
                  <i class="remove ti-close"></i>
                </li>
                <li>
                  <div class="form-check">
                    <label class="form-check-label">
                      <input class="checkbox" type="checkbox">
                      Prepare for presentation
                    </label>
                  </div>
                  <i class="remove ti-close"></i>
                </li>
                <li>
                  <div class="form-check">
                    <label class="form-check-label">
                      <input class="checkbox" type="checkbox">
                      Resolve all the low priority tickets due today
                    </label>
                  </div>
                  <i class="remove ti-close"></i>
                </li>
                <li class="completed">
                  <div class="form-check">
                    <label class="form-check-label">
                      <input class="checkbox" type="checkbox" checked>
                      Schedule meeting for next week
                    </label>
                  </div>
                  <i class="remove ti-close"></i>
                </li>
                <li class="completed">
                  <div class="form-check">
                    <label class="form-check-label">
                      <input class="checkbox" type="checkbox" checked>
                      Project review
                    </label>
                  </div>
                  <i class="remove ti-close"></i>
                </li>
              </ul>
            </div>
            <h4 class="px-3 text-muted mt-5 fw-light mb-0">Events</h4>
            <div class="events pt-4 px-3">
              <div class="wrapper d-flex mb-2">
                <i class="ti-control-record text-primary me-2"></i>
                <span>Feb 11 2018</span>
              </div>
              <p class="mb-0 font-weight-thin text-gray">Creating component page build a js</p>
              <p class="text-gray mb-0">The total number of sessions</p>
            </div>
            <div class="events pt-4 px-3">
              <div class="wrapper d-flex mb-2">
                <i class="ti-control-record text-primary me-2"></i>
                <span>Feb 7 2018</span>
              </div>
              <p class="mb-0 font-weight-thin text-gray">Meeting with Alisa</p>
              <p class="text-gray mb-0 ">Call Sarah Graves</p>
            </div>
          </div>
          <!-- To do section tab ends -->
          <div class="tab-pane fade" id="chats-section" role="tabpanel" aria-labelledby="chats-section">
            <div class="d-flex align-items-center justify-content-between border-bottom">
              <p class="settings-heading border-top-0 mb-3 pl-3 pt-0 border-bottom-0 pb-0">Friends</p>
              <small class="settings-heading border-top-0 mb-3 pt-0 border-bottom-0 pb-0 pr-3 fw-normal">See All</small>
            </div>
            <ul class="chat-list">
              <li class="list active">
                <div class="profile"><img src="images/faces/face1.jpg" alt="image"><span class="online"></span></div>
                <div class="info">
                  <p>Thomas Douglas</p>
                  <p>Available</p>
                </div>
                <small class="text-muted my-auto">19 min</small>
              </li>
              <li class="list">
                <div class="profile"><img src="images/faces/face2.jpg" alt="image"><span class="offline"></span></div>
                <div class="info">
                  <div class="wrapper d-flex">
                    <p>Catherine</p>
                  </div>
                  <p>Away</p>
                </div>
                <div class="badge badge-success badge-pill my-auto mx-2">4</div>
                <small class="text-muted my-auto">23 min</small>
              </li>
              <li class="list">
                <div class="profile"><img src="images/faces/face3.jpg" alt="image"><span class="online"></span></div>
                <div class="info">
                  <p>Daniel Russell</p>
                  <p>Available</p>
                </div>
                <small class="text-muted my-auto">14 min</small>
              </li>
              <li class="list">
                <div class="profile"><img src="images/faces/face4.jpg" alt="image"><span class="offline"></span></div>
                <div class="info">
                  <p>James Richardson</p>
                  <p>Away</p>
                </div>
                <small class="text-muted my-auto">2 min</small>
              </li>
              <li class="list">
                <div class="profile"><img src="images/faces/face5.jpg" alt="image"><span class="online"></span></div>
                <div class="info">
                  <p>Madeline Kennedy</p>
                  <p>Available</p>
                </div>
                <small class="text-muted my-auto">5 min</small>
              </li>
              <li class="list">
                <div class="profile"><img src="images/faces/face6.jpg" alt="image"><span class="online"></span></div>
                <div class="info">
                  <p>Sarah Graves</p>
                  <p>Available</p>
                </div>
                <small class="text-muted my-auto">47 min</small>
              </li>
            </ul>
          </div>
          <!-- chat tab ends -->
        </div>
      </div>
      <!-- partial -->
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav" style="color: black;">
          <li class="nav-item">
            <a class="nav-link" href="dashboard.php">
            <i class="fa-solid fa-house fa-2x fa-lg" style="color: #b4dbbb;"></i>
              <span class="menu-title" style="color:black" > &nbsp; &nbsp; Inicio</span>
            </a>
          </li>
          <li class="nav-item nav-category">Modulos</li>
          <li class="nav-item">
            <?php
              if($_SESSION['rol']=="Administrador"){

            ?>
            <a class="nav-link" data-bs-toggle="collapse" href="#table2" aria-expanded="false" aria-controls="tables">
            <i class="fa-solid fa-user fa-2x fa-lg" style="color: #94D49F;"></i>
              <span class="menu-title" style="color:black"> &nbsp; &nbsp; Usuarios</span>
              <i class="menu-arrow"></i>
            </a>
            
            <div class="collapse" id="table2">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=gestion_usuarios" style="color:black">Gestión de usuarios</a></li>
              </ul>
            </div>
            <div class="collapse" id="table2">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=crear_usuarios" style="color:black">Crear usuario</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#tabla" aria-expanded="false" aria-controls="tables">
            <i class="fa-solid fa-folder-open fa-2x fa-lg" style="color: #94D49F;" ></i>
              <span class="menu-title" style="color:black"> &nbsp; &nbsp;&nbsp;Documentos</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="tabla">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=modificar_archivos" style="color:black">Gestión de historial</a></li>
              </ul>
            </div>
            <div class="collapse" id="tabla">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=subir_doc" style="color:black">Crear documentos</a></li>
              </ul>
            </div>
          </li>


          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#tableee" aria-expanded="false" aria-controls="tableee">
            <i class="fa-solid fa-folder-open fa-2x fa-lg" style="color: #94D49F;" ></i>
              <span class="menu-title" style="color:black"> &nbsp; &nbsp;&nbsp;Servicios</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="tableee">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=gestion_servicios" style="color:black">Gestion de servicios</a></li>
              </ul>
            </div>
            <div class="collapse" id="tableee">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=crear_servicios" style="color:black">Crear servicios</a></li>
              </ul>
            </div>
          </li>
    

          <?php
              }
            ?>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#table" aria-expanded="false" aria-controls="tables">
            <i class="fa-solid fa-head-side-virus fa-2x fa-lg" style="color: #94D49F;"></i>
              <span class="menu-title" style="color:black"> &nbsp; &nbsp;Psicología</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="table">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=adultos" style="color:black">Adultos</a></li>
              </ul>
            </div>
            <div class="collapse" id="table">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=adolescencia" style="color:black">Adolescencia</a></li>
              </ul>
            </div>
            <div class="collapse" id="table">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=parejas" style="color:black">Parejas</a></li>
              </ul>
            </div>
            <div class="collapse" id="table">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=familia" style="color:black">Familia</a></li>
              </ul>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#tablesl" aria-expanded="false" aria-controls="tables">
            <i class="fa-solid fa-shield-dog fa-2x fa-lg" style="color: #94D49F;"></i>
              <span class="menu-title" style="color:black" >&nbsp; &nbsp;Veterinaria</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="tablesl">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=anes" style="color:black">Anestesiología veterinaria</a></li>
              </ul>
            </div>
            <div class="collapse" id="tablesl">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=cardio" style="color:black">Cardiología veterinaria</a></li>
              </ul>
            </div>
            <div class="collapse" id="tablesl">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=cirugia" style="color:black">Cirugía </a></li>
              </ul>
            </div>
            <div class="collapse" id="tablesl">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=dermatologia" style="color:black">Dermatología</a></li>
              </ul>
            </div>
            <div class="collapse" id="tablesl">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=fisioterapia" style="color:black">Fisioterapia</a></li>
              </ul>
            </div>
            <div class="collapse" id="tablesl">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=neuro" style="color:black">Neurología</a></li>
              </ul>
            </div>
            <div class="collapse" id="tablesl">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=ortopedia" style="color:black">Ortopedia</a></li>
              </ul>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#tabless" aria-expanded="false" aria-controls="tables">
            <i class="fa-brands fa-apple fa-2x fa-lg" style="color: #94D49F;"></i>
              <span class="menu-title" style="color:black"> &nbsp; &nbsp;Nutrición</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="tabless">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=pediatrica" style="color:black">Pediátrica</a></li>
              </ul>
            </div>
            <div class="collapse" id="tabless">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=vegetariana" style="color:black">Vegetariana</a></li>
              </ul>
            </div>
            <div class="collapse" id="tabless">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=vegana" style="color:black">Vegana</a></li>
              </ul>
            </div>
            <div class="collapse" id="tabless">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=clinica" style="color:black">Clínica</a></li>
              </ul>
            </div>
            <div class="collapse" id="tabless">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=higiene" style="color:black">Higiene</a></li>
              </ul>
            </div>
            <div class="collapse" id="tabless">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=seguridad" style="color:black">Seguridad alimentaria</a></li>
              </ul>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#tabl" aria-expanded="false" aria-controls="tables">
            <i class="fa-solid fa-gift fa-2x fa-lg" style="color: #94D49F;" ></i>
              <span class="menu-title" style="color:black"> &nbsp; &nbsp;Organización <br> &nbsp; &nbsp;de eventos</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="tabl">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=15" style="color:black">15 años</a></li>
              </ul>
            </div>
            <div class="collapse" id="tabl">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=comunion" style="color:black">Primera Comunión</a></li>
              </ul>
            </div>
            <div class="collapse" id="tabl">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=boda" style="color:black">Bodas</a></li>
              </ul>
            </div>
            <div class="collapse" id="tabl">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=buffet" style="color:black">Buffets</a></li>
              </ul>
            </div>
            <div class="collapse" id="tabl">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=cumple" style="color:black">Cumpleaños</a></li>
              </ul>
            </div>
            <div class="collapse" id="tabl">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=graduacion" style="color:black">Graduaciones</a></li>
              </ul>
            </div>
            <div class="collapse" id="tabl">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="dashboard.php?mod=reunion" style="color:black">Reuniones Sociales</a></li>
              </ul>
            </div>
          </li>
          <li class="nav-item nav-category">Recursos</li>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#charts" aria-expanded="false" aria-controls="charts">
            <i class="fa-solid fa-comments fa-2x fa-lg" style="color: #94D49F;"></i>
              <span class="menu-title" style="color:black">&nbsp; &nbsp;&nbsp;Chat</span>
            </a>
          </li>
        
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#t" aria-expanded="false" aria-controls="charts">
              <span class="menu-title" href="dashboard.php?mod=nosotras">&nbsp; &nbsp;&nbsp;Nosotras</span>
            </a>
          </li>
        
      </nav>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-sm-12">
              <div class="home-tab">
                <div class="d-sm-flex align-items-center justify-content-between border-bottom">
                  
                  
                
                </div>
                <div>
                <?php
                  if(@ $_GET['mod']==""){

                  require_once("modulos/inicio.php");

                }
                else
                if(@ $_GET['mod']=="miperfil"){
                  
                require_once("modulos/miperfil.php");

              }
                else
                if(@ $_GET['mod']=="inicio"){
                  
                require_once("modulos/inicio.php");

              }
              else
                if (@ $_GET['mod']=="gestion_usuarios"){

                  require_once("modulos/gestion_usuarios.php");

              }
              else
                if (@ $_GET['mod']=="crear_usuarios"){

                  require_once("modulos/crear_usuarios.php");

              }
              else
                if (@ $_GET['mod']=="adultos"){

                  require_once("modulos/adultos.php");

              }
              else
                if (@ $_GET['mod']=="adolescencia"){

                  require_once("modulos/adolescencia.php");

              }
              else
                if (@ $_GET['mod']=="parejas"){

                  require_once("modulos/parejas.php");

              }
              else
                if (@ $_GET['mod']=="familia"){

                  require_once("modulos/familia.php");

              }
              else
              if (@ $_GET['mod']=="anes"){

                require_once("modulos/anes.php");

            }
            else
                if (@ $_GET['mod']=="cardio"){

                  require_once("modulos/cardio.php");

              }
              else
                if (@ $_GET['mod']=="cirugia"){

                  require_once("modulos/cirugia.php");

              }
              else
                if (@ $_GET['mod']=="dermatologia"){

                  require_once("modulos/dermatologia.php");

              }
              else
                if (@ $_GET['mod']=="fisioterapia"){

                  require_once("modulos/fisioterapia.php");

              }
              else
                if (@ $_GET['mod']=="neuro"){

                  require_once("modulos/neuro.php");

              }
              else
              if (@ $_GET['mod']=="ortopedia"){

                require_once("modulos/ortopedia.php");

            }
            else
              if (@ $_GET['mod']=="pediatrica"){

                require_once("modulos/pediatrica.php");

            }
            else
              if (@ $_GET['mod']=="vegetariana"){

                require_once("modulos/vegetariana.php");

            }
            else
              if (@ $_GET['mod']=="vegana"){

                require_once("modulos/vegana.php");

            }
            else
              if (@ $_GET['mod']=="clinica"){

                require_once("modulos/clinica.php");

            }
            else
              if (@ $_GET['mod']=="higiene"){

                require_once("modulos/higiene.php");

            }
            else
              if (@ $_GET['mod']=="seguridad"){

                require_once("modulos/seguridad.php");

            }
            else
              if (@ $_GET['mod']=="15"){

                require_once("modulos/15.php");

            }
            else
              if (@ $_GET['mod']=="comunion"){

                require_once("modulos/comunion.php");

            }
            else
              if (@ $_GET['mod']=="boda"){

                require_once("modulos/boda.php");

            }
            else
              if (@ $_GET['mod']=="buffet"){

                require_once("modulos/buffet.php");

            }
            else
              if (@ $_GET['mod']=="cumple"){

                require_once("modulos/cumple.php");

            }
            else
              if (@ $_GET['mod']=="graduacion"){

                require_once("modulos/graduacion.php");

            }
            else
              if (@ $_GET['mod']=="reunion"){

                require_once("modulos/reunion.php");

            }

            else
              if (@ $_GET['mod']=="nosotras"){

                require_once("modulos/nosotras.php");

            }
            else
              if (@ $_GET['mod']=="subir_doc"){

                require_once("modulos/subir_doc.php");

            }
            else
              if (@ $_GET['mod']=="modificar_archivos"){

                require_once("modulos/modificar_archivos.php");

            }
            else
            if (@ $_GET['mod']=="crear_servicios"){

              require_once("modulos/crear_servicios.php");

          }
          else
          if (@ $_GET['mod']=="gestion_servicios"){

            require_once("modulos/gestion_servicios.php");

        }
                  ?>
                </div>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
     
       
    </div>
    <!-- page-body-wrapper ends -->
    
   
  
</div>
          </div>
<footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
          &nbsp;&nbsp;&nbsp;<span class="text-muted text-center text-sm-left d-block d-sm-inline-block"> <i class="fa-brands fa-facebook-f" style="color:#0A0909; width:12; height:12; cursor:pointer;"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <i class="fa-brands fa-instagram" style="color:#0A0909; cursor:pointer;"></i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a> <i class="fa-brands fa-twitter" style="color:#0A0909; cursor:pointer;"></i>&nbsp;&nbsp;&nbsp;&nbsp; <br><br>Contacto: aseoria@gmail.com &nbsp;| &nbsp; Medellin-Colombia &nbsp;| &nbsp; Calle43A #112 </span> 
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Copyright © 2023. Todos los derechos reservados.</span>
          </div>
        </footer>
</html>

