<?php
    
  //la informacion solo se envia si le das al boton. if (condicion) (isset (para verificar) ($_POST (metodo de envio mas seguro) ['btn_registrar'] (nombre del boton en el form)))
  if(isset($_POST['btn_documento'])){

    // llamar a la conexion de otro archivo (poner el nombre del otro archivo php)
    include ("conexion.php");


    //llamado de las variables ej: $nom_1 (nombre inventado) = $_POST (metodo de envio) ['nombre1'] (nombre en el formulario); 
    $cod_a = $_POST['ca'];
    $fe_sub = $_POST['fs'];
    $tip_a = $_POST['ta'];
    $nom_a = $_POST['na'];
    $des_a = $_POST['da'];
    $n_id = $_POST['nu_id'];
  
    //registrar los datos en la tabla $registrar (variable)= mysqli_query (para insertar codigo de mysql) ($conexion (variable), "insert into usuario (nombre de la tabla) (nombres de los campos en phpmyadmin) values (nombre de las variables)")
    $registrar = mysqli_query($conexion,"INSERT INTO `histo_document` (`cod_archivo`, `fecha_subida`, `tip_arch`, `nomb_arch`, `descripci_arch`, `fk_usu_histo`) VALUES ('$cod_a', '$fe_sub', '$tip_a', '$nom_a', '$des_a', '$n_id');");

    echo "<script> alert('Registro exitoso'); </script>";

    echo "<script> window.location='index.php'; </script>";

  } 
  
?>